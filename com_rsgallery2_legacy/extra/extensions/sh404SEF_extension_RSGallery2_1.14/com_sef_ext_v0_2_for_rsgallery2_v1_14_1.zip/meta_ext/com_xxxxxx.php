<?php
/**
This file is only needed for the installer.
See http://extensions.siliana.net/Forum/sh404SEF-plugins/6088-sh404SEF-PlugIn-installer.html for details.
 */

?>